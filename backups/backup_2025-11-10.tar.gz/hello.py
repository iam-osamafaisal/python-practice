name = name("enter your name: ")
print("Hello world!")
#print("This is a simple Python script.")
#print("It prints multiple lines to the console.")
