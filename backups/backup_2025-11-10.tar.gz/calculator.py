num1 = int(input("Enter First number: ")) #str -> int Type Casting
num2 = int(input("Enter Second number: "))

print(type(num1))
print(type(num2))

sum_of_num = num1 + num2

print("Sum of 2 numbers: ",sum_of_num)

diff_of_num = num1 - num2

print("Diff of numbers= ",diff_of_num)

#sum_of_num = num1 * num2

#print("product of 2 numbers: ",prod_of_num)

#diff_of_num = num1 / num2

#print("Diff of numbers= ",diff_of_num)