import os #Importing a library into your code

print(os.system('df -h')) # Linux or Mac
print(os.system('uptime')) # uptime and load average
print(os.system('free -h')) # RAM for Linux 
print(os.system('sysinfo')) # For Windows